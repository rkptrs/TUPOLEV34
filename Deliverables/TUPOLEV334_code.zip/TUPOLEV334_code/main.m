% close all;
% clc;
% clear all;

%First run the part for the reference aircraft for initial CST coefficients
%and A-W contribution
tic;

Ref_data;

global data;
x0 = data.x0;
ub = data.ub;
lb = data.lb;

x0n = (x0-lb)./(ub-lb);
lbn = 0.*lb;
ubn = ub./ub;

% options.OutputFcn = {@constraints};
options.Algorithm = 'sqp';
options.Display = 'iter-detailed';
options.DiffMinChange = 0.0001;
options.DiffMaxChange = 0.4;
options.TolFun = 0.0001;
%options.TolX = 0.0001;
options.TolCon = 0.001;
options.PlotFcns = {@optimplotfval};
[x, fval, exitflag, output] = fmincon(@(x) MDA(x), x0n, [], [], [], [], lbn, ubn, @(x) constraints(x), options); 
toc;
